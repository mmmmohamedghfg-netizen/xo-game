import re

p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
s = re.sub(r'android:label="[^"]*"', 'android:label="إكس أو"', s, count=1)
perms = (
    '<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>\n'
    '    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>\n'
    '    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>\n'
    '    <uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE"/>\n'
    '    <uses-feature android:name="android.hardware.bluetooth" android:required="false"/>\n'
    '    '
)
s = s.replace('<application', perms + '<application', 1)
open(p, 'w', encoding='utf-8').write(s)
print(s)
