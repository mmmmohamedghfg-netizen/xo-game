package com.xogame.xo_game

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val uuid: UUID = UUID.fromString("8b4f5d2e-3c1a-4e6b-9f7d-2a1b0c9d8e7f")
    private lateinit var channel: MethodChannel
    private val ui = Handler(Looper.getMainLooper())
    private val writer = Executors.newSingleThreadExecutor()
    private var socket: BluetoothSocket? = null
    private var server: BluetoothServerSocket? = null
    private var gen = 0
    private var pendingPerm: MethodChannel.Result? = null
    private var pendingEnable: MethodChannel.Result? = null

    private fun adapter(): BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    private fun needed(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
        else arrayOf()

    private fun granted(): Boolean =
        needed().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun emitIf(my: Int, type: String, data: String = "") {
        ui.post {
            if (my == gen) channel.invokeMethod("event", mapOf("type" to type, "data" to data))
        }
    }

    private fun closeAll() {
        gen++
        try { socket?.close() } catch (e: Throwable) {}
        try { server?.close() } catch (e: Throwable) {}
        socket = null
        server = null
    }

    private fun attach(s: BluetoothSocket, my: Int) {
        socket = s
        val name = try { s.remoteDevice.name ?: "" } catch (e: Throwable) { "" }
        emitIf(my, "connected", name)
        try {
            val r = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
            while (true) {
                val line = r.readLine() ?: break
                emitIf(my, "msg", line)
            }
        } catch (e: Throwable) {
        }
        emitIf(my, "disconnected")
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "xo/bt")
        channel.setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "ensure" -> {
                        if (granted()) result.success(true)
                        else {
                            pendingPerm = result
                            requestPermissions(needed(), 77)
                        }
                    }
                    "enable" -> {
                        val a = adapter()
                        if (a == null) result.success(false)
                        else if (a.isEnabled) result.success(true)
                        else {
                            pendingEnable = result
                            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 78)
                        }
                    }
                    "bonded" -> {
                        val list = try {
                            adapter()?.bondedDevices?.map {
                                mapOf("name" to (it.name ?: it.address), "address" to it.address)
                            } ?: emptyList()
                        } catch (e: SecurityException) {
                            emptyList()
                        }
                        result.success(list)
                    }
                    "host" -> {
                        closeAll()
                        val my = gen
                        Thread {
                            try {
                                val srv = adapter()!!.listenUsingRfcommWithServiceRecord("XO", uuid)
                                server = srv
                                emitIf(my, "waiting")
                                val s = srv.accept()
                                try { srv.close() } catch (e: Throwable) {}
                                server = null
                                attach(s, my)
                            } catch (e: Throwable) {
                                emitIf(my, "error", e.message ?: "host")
                            }
                        }.start()
                        result.success(null)
                    }
                    "connect" -> {
                        val addr = call.argument<String>("address")!!
                        closeAll()
                        val my = gen
                        Thread {
                            try {
                                val a = adapter()!!
                                a.cancelDiscovery()
                                val s = a.getRemoteDevice(addr).createRfcommSocketToServiceRecord(uuid)
                                s.connect()
                                attach(s, my)
                            } catch (e: Throwable) {
                                emitIf(my, "error", e.message ?: "connect")
                            }
                        }.start()
                        result.success(null)
                    }
                    "send" -> {
                        val t = call.argument<String>("text")!!
                        writer.execute {
                            try {
                                val o = socket?.outputStream
                                if (o != null) {
                                    o.write((t + "\n").toByteArray(Charsets.UTF_8))
                                    o.flush()
                                }
                            } catch (e: Throwable) {
                            }
                        }
                        result.success(null)
                    }
                    "discoverable" -> {
                        try {
                            startActivity(
                                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
                            )
                        } catch (e: Throwable) {
                        }
                        result.success(null)
                    }
                    "settings" -> {
                        startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                        result.success(null)
                    }
                    "close" -> {
                        closeAll()
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Throwable) {
                result.error("ERR", e.message, null)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) {
            pendingPerm?.success(grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })
            pendingPerm = null
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78) {
            pendingEnable?.success(resultCode == Activity.RESULT_OK)
            pendingEnable = null
        }
    }

    override fun onDestroy() {
        closeAll()
        super.onDestroy()
    }
}
