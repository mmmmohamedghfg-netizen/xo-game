import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  cfg.load();
  runApp(const App());
}

// ---------- الإعدادات (ألوان + مظهر) ----------
class Cfg extends ChangeNotifier {
  int pal = 0;
  ThemeMode mode = ThemeMode.system;
  static const pals = [
    [Color(0xFF4CC9F0), Color(0xFFF72585)],
    [Color(0xFFFF9F1C), Color(0xFF2EC4B6)],
    [Color(0xFF70E000), Color(0xFFFF5D8F)],
    [Color(0xFFB388FF), Color(0xFFFFD166)],
  ];
  Color get xc => pals[pal][0];
  Color get oc => pals[pal][1];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    pal = p.getInt('pal') ?? 0;
    mode = ThemeMode.values[p.getInt('theme') ?? 0];
    notifyListeners();
  }

  Future<void> set({int? pal, ThemeMode? mode}) async {
    if (pal != null) this.pal = pal;
    if (mode != null) this.mode = mode;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setInt('pal', this.pal);
    await p.setInt('theme', this.mode.index);
  }
}

final cfg = Cfg();

// حكم الخاسر (يُختار عشوائياً)
const hukms = [
  'الصلاة على النبي ﷺ 7 مرات',
  'التسبيح 7 مرات (سبحان الله)',
  'الاستغفار 7 مرات (أستغفر الله)',
  'قول الحمد لله 7 مرات',
];

// ---------- جسر البلوتوث (كود Kotlin) ----------
class Bt {
  static const ch = MethodChannel('xo/bt');
  static void Function(String, String)? _h;
  static final List<List<String>> _q = [];
  static bool _init = false;

  static void init() {
    if (_init) return;
    _init = true;
    ch.setMethodCallHandler((call) async {
      if (call.method == 'event') {
        final m = Map<String, dynamic>.from(call.arguments as Map);
        final t = m['type'] as String, d = (m['data'] ?? '') as String;
        if (_h == null) {
          _q.add([t, d]);
        } else {
          _h!(t, d);
        }
      }
    });
  }

  static set onEvent(void Function(String, String)? h) {
    _h = h;
    if (h != null) {
      final q = List<List<String>>.from(_q);
      _q.clear();
      for (final e in q) {
        h(e[0], e[1]);
      }
    }
  }

  static Future<bool> ready() async {
    init();
    final p = await ch.invokeMethod<bool>('ensure') ?? false;
    if (!p) return false;
    return await ch.invokeMethod<bool>('enable') ?? false;
  }

  static Future<List<Map<String, String>>> bonded() async {
    final r = await ch.invokeMethod<List<dynamic>>('bonded') ?? [];
    return r.map((e) => Map<String, String>.from(e as Map)).toList();
  }

  static Future<void> host() => ch.invokeMethod('host');
  static Future<void> connect(String a) => ch.invokeMethod('connect', {'address': a});
  static Future<void> discoverable() => ch.invokeMethod('discoverable');
  static Future<void> settings() => ch.invokeMethod('settings');
  static Future<void> close() => ch.invokeMethod('close');
  static void send(String t) => ch.invokeMethod('send', {'text': t});
}

// ---------- منطق اللعبة ----------
const lines = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]
];

List<int>? winLine(List<String> b) {
  for (final l in lines) {
    if (b[l[0]] != '' && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) return l;
  }
  return null;
}

int _mm(List<String> b, String turn, String ai, String hu, int depth) {
  final w = winLine(b);
  if (w != null) return b[w[0]] == ai ? 10 - depth : depth - 10;
  if (!b.contains('')) return 0;
  var best = turn == ai ? -100 : 100;
  for (var i = 0; i < 9; i++) {
    if (b[i] != '') continue;
    b[i] = turn;
    final s = _mm(b, turn == ai ? hu : ai, ai, hu, depth + 1);
    b[i] = '';
    if (turn == ai) {
      if (s > best) best = s;
    } else {
      if (s < best) best = s;
    }
  }
  return best;
}

int aiMove(List<String> b, String ai, String hu, int diff) {
  final empty = [for (var i = 0; i < 9; i++) if (b[i] == '') i];
  final r = Random();
  if (diff == 0) return empty[r.nextInt(empty.length)];
  if (diff == 1) {
    for (final m in empty) {
      b[m] = ai;
      final w = winLine(b);
      b[m] = '';
      if (w != null) return m;
    }
    for (final m in empty) {
      b[m] = hu;
      final w = winLine(b);
      b[m] = '';
      if (w != null) return m;
    }
    return empty[r.nextInt(empty.length)];
  }
  var bs = -100;
  var moves = <int>[];
  for (final m in empty) {
    b[m] = ai;
    final s = _mm(b, hu, ai, hu, 1);
    b[m] = '';
    if (s > bs) {
      bs = s;
      moves = [m];
    } else if (s == bs) {
      moves.add(m);
    }
  }
  return moves[r.nextInt(moves.length)];
}

// ---------- الرسم ----------
class GridPainter extends CustomPainter {
  final Color c;
  GridPainter(this.c);
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()
      ..color = c
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;
    final t = s.width / 3;
    for (var i = 1; i < 3; i++) {
      canvas.drawLine(Offset(t * i, 12), Offset(t * i, s.height - 12), p);
      canvas.drawLine(Offset(12, t * i), Offset(s.width - 12, t * i), p);
    }
  }

  @override
  bool shouldRepaint(covariant GridPainter o) => o.c != c;
}

class MarkPainter extends CustomPainter {
  final bool x;
  final double t;
  final Color c;
  MarkPainter(this.x, this.t, this.c);
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()
      ..color = c
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12
      ..strokeCap = StrokeCap.round;
    final e = s.width - 6.0;
    if (x) {
      final a = (t * 2).clamp(0.0, 1.0);
      final b = (t * 2 - 1).clamp(0.0, 1.0);
      canvas.drawLine(const Offset(6, 6), Offset(6 + (e - 6) * a, 6 + (e - 6) * a), p);
      if (b > 0) {
        canvas.drawLine(Offset(e, 6), Offset(e - (e - 6) * b, 6 + (e - 6) * b), p);
      }
    } else {
      canvas.drawArc(Rect.fromLTWH(0, 0, s.width, s.height).deflate(6), -pi / 2, 2 * pi * t, false, p);
    }
  }

  @override
  bool shouldRepaint(covariant MarkPainter o) => true;
}

class LinePainter extends CustomPainter {
  final List<int> l;
  final double t;
  final Color c;
  LinePainter(this.l, this.t, this.c);
  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width / 3;
    Offset cell(int i) => Offset((i % 3 + .5) * w, (i ~/ 3 + .5) * w);
    final a = cell(l[0]), b = cell(l[2]);
    final end = Offset.lerp(a, b, t)!;
    canvas.drawLine(
        a,
        end,
        Paint()
          ..color = c
          ..strokeWidth = 9
          ..strokeCap = StrokeCap.round);
  }

  @override
  bool shouldRepaint(covariant LinePainter o) => true;
}

class Board extends StatelessWidget {
  final List<String> cells;
  final List<int>? line;
  final void Function(int) onTap;
  const Board({super.key, required this.cells, required this.line, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final ln = line;
    final cs = Theme.of(context).colorScheme;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: AspectRatio(
        aspectRatio: 1,
        child: LayoutBuilder(builder: (context, bc) {
          final s = bc.maxWidth;
          final m = s / 3 * 0.56;
          return Stack(children: [
            CustomPaint(size: Size(s, s), painter: GridPainter(cs.outlineVariant)),
            GridView.count(
              crossAxisCount: 3,
              physics: const NeverScrollableScrollPhysics(),
              padding: EdgeInsets.zero,
              children: List.generate(9, (i) {
                final v = cells[i];
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: Center(
                    child: v == ''
                        ? const SizedBox()
                        : TweenAnimationBuilder<double>(
                            key: ValueKey('$i$v'),
                            tween: Tween(begin: 0, end: 1),
                            duration: const Duration(milliseconds: 320),
                            builder: (_, t, __) => CustomPaint(
                              size: Size(m, m),
                              painter: MarkPainter(v == 'X', t, v == 'X' ? cfg.xc : cfg.oc),
                            ),
                          ),
                  ),
                );
              }),
            ),
            if (ln != null)
              IgnorePointer(
                child: TweenAnimationBuilder<double>(
                  key: ValueKey(ln.toString()),
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 450),
                  builder: (_, t, __) => CustomPaint(size: Size(s, s), painter: LinePainter(ln, t, cs.onSurface)),
                ),
              ),
          ]);
        }),
      ),
    );
  }
}

// ---------- التطبيق ----------
class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: cfg,
        builder: (_, __) => MaterialApp(
          title: 'إكس أو',
          debugShowCheckedModeBanner: false,
          themeMode: cfg.mode,
          theme: ThemeData(colorSchemeSeed: const Color(0xFF6C4DFF), useMaterial3: true),
          darkTheme: ThemeData(colorSchemeSeed: const Color(0xFF6C4DFF), brightness: Brightness.dark, useMaterial3: true),
          builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
          home: const Home(),
        ),
      );
}

enum Mode { ai, local, bt }

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int diff = 1;
  void open(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  void settings() {
    showModalBottomSheet(
      context: context,
      builder: (_) => AnimatedBuilder(
        animation: cfg,
        builder: (_, __) => Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('الألوان', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Row(children: [
              for (var i = 0; i < Cfg.pals.length; i++)
                GestureDetector(
                  onTap: () => cfg.set(pal: i),
                  child: Container(
                    margin: const EdgeInsets.only(left: 12),
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: cfg.pal == i ? Theme.of(context).colorScheme.primary : Colors.transparent, width: 3),
                    ),
                    child: Row(children: [
                      CircleAvatar(radius: 13, backgroundColor: Cfg.pals[i][0]),
                      CircleAvatar(radius: 13, backgroundColor: Cfg.pals[i][1]),
                    ]),
                  ),
                ),
            ]),
            const SizedBox(height: 20),
            const Text('المظهر', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('تلقائي')),
                ButtonSegment(value: ThemeMode.light, label: Text('نهاري')),
                ButtonSegment(value: ThemeMode.dark, label: Text('ليلي')),
              ],
              selected: {cfg.mode},
              onSelectionChanged: (s) => cfg.set(mode: s.first),
            ),
            const SizedBox(height: 12),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: cfg,
      builder: (_, __) => Scaffold(
        appBar: AppBar(actions: [IconButton(icon: const Icon(Icons.palette_outlined), onPressed: settings)]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Center(
            child: Directionality(
              textDirection: TextDirection.ltr,
              child: Text.rich(TextSpan(children: [
                TextSpan(text: 'X', style: TextStyle(color: cfg.xc)),
                TextSpan(text: 'O', style: TextStyle(color: cfg.oc)),
              ], style: const TextStyle(fontSize: 84, fontWeight: FontWeight.w900, letterSpacing: 6))),
            ),
          ),
          const SizedBox(height: 16),
          ModeCard(
              icon: Icons.smart_toy_outlined,
              title: 'ضد الكمبيوتر',
              sub: 'اختر مستوى الصعوبة بالأسفل',
              onTap: () => open(GamePage(mode: Mode.ai, diff: diff))),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('سهل')),
                ButtonSegment(value: 1, label: Text('متوسط')),
                ButtonSegment(value: 2, label: Text('مستحيل')),
              ],
              selected: {diff},
              onSelectionChanged: (s) => setState(() => diff = s.first),
            ),
          ),
          ModeCard(
              icon: Icons.people_outline,
              title: 'لاعبان على نفس الجهاز',
              sub: 'مرّر الموبايل بينكما',
              onTap: () => open(const GamePage(mode: Mode.local))),
          ModeCard(
              icon: Icons.bluetooth,
              title: 'لعب بالبلوتوث',
              sub: 'العب مع صديق على جهاز آخر',
              onTap: () => open(const BtLobby())),
        ]),
      ),
    );
  }
}

class ModeCard extends StatelessWidget {
  final IconData icon;
  final String title, sub;
  final VoidCallback onTap;
  const ModeCard({super.key, required this.icon, required this.title, required this.sub, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: ListTile(
          contentPadding: const EdgeInsets.all(16),
          leading: CircleAvatar(radius: 26, child: Icon(icon)),
          title: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          subtitle: Text(sub),
          onTap: onTap,
        ),
      );
}

// ---------- صالة البلوتوث ----------
class BtLobby extends StatefulWidget {
  const BtLobby({super.key});
  @override
  State<BtLobby> createState() => _LobbyState();
}

class _LobbyState extends State<BtLobby> {
  String state = 'idle'; // idle, waiting, list, connecting
  List<Map<String, String>> devices = [];
  String msg = '';
  bool isHost = true, going = false;

  @override
  void initState() {
    super.initState();
    Bt.init();
    Bt.onEvent = onEv;
  }

  @override
  void dispose() {
    if (!going) {
      Bt.close();
      Bt.onEvent = null;
    }
    super.dispose();
  }

  void onEv(String type, String data) {
    if (!mounted || going) return;
    if (type == 'connected') {
      going = true;
      Bt.onEvent = null;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (_) => GamePage(mode: Mode.bt, host: isHost, opp: data.isEmpty ? 'الخصم' : data)),
      );
    } else if (type == 'error') {
      setState(() {
        state = 'idle';
        msg = 'تعذر الاتصال. تأكد أن الطرف الآخر اختار "استضافة" وأن الجهازين مقترنان.';
      });
    }
  }

  Future<bool> prep() async {
    final ok = await Bt.ready();
    if (!ok && mounted) setState(() => msg = 'فعّل البلوتوث وامنح الإذن ثم حاول مرة أخرى.');
    return ok;
  }

  Future<void> host() async {
    if (!await prep()) return;
    isHost = true;
    await Bt.host();
    setState(() {
      state = 'waiting';
      msg = '';
    });
    await Bt.discoverable();
  }

  Future<void> join() async {
    if (!await prep()) return;
    isHost = false;
    final d = await Bt.bonded();
    setState(() {
      devices = d;
      state = 'list';
      msg = '';
    });
  }

  Future<void> connect(String addr) async {
    setState(() {
      state = 'connecting';
      msg = '';
    });
    await Bt.connect(addr);
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (state == 'waiting' || state == 'connecting') {
      body = Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const CircularProgressIndicator(),
        const SizedBox(height: 20),
        Text(state == 'waiting' ? 'في انتظار اللاعب الآخر...' : 'جاري الاتصال...', style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 20),
        OutlinedButton(
            onPressed: () {
              Bt.close();
              setState(() => state = 'idle');
            },
            child: const Text('إلغاء')),
      ]);
    } else if (state == 'list') {
      body = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('اختر جهاز صديقك (لازم يكون ضغط "استضافة" أولاً):', style: TextStyle(fontSize: 16)),
        const SizedBox(height: 8),
        Expanded(
          child: devices.isEmpty
              ? const Center(child: Text('لا توجد أجهزة مقترنة. اقترن بالجهاز الآخر من إعدادات البلوتوث أولاً.'))
              : ListView(children: [
                  for (final d in devices)
                    Card(
                        child: ListTile(
                            leading: const Icon(Icons.phone_android),
                            title: Text(d['name'] ?? ''),
                            subtitle: Text(d['address'] ?? ''),
                            onTap: () => connect(d['address']!))),
                ]),
        ),
        TextButton.icon(onPressed: Bt.settings, icon: const Icon(Icons.settings_bluetooth), label: const Text('إعدادات البلوتوث')),
      ]);
    } else {
      body = ListView(children: [
        const Text(
            'خطوات اللعب:\n'
            '1) اقترن بالجهاز الآخر مرة واحدة من إعدادات البلوتوث.\n'
            '2) أحدكما يختار "استضافة" (يلعب X).\n'
            '3) الآخر يختار "انضمام" ثم يضغط على اسم جهاز المضيف (يلعب O).',
            style: TextStyle(fontSize: 15, height: 1.8)),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: host, icon: const Icon(Icons.wifi_tethering), label: const Text('استضافة لعبة')),
        const SizedBox(height: 10),
        FilledButton.tonalIcon(onPressed: join, icon: const Icon(Icons.login), label: const Text('انضمام للعبة')),
        const SizedBox(height: 10),
        TextButton.icon(onPressed: Bt.settings, icon: const Icon(Icons.settings_bluetooth), label: const Text('فتح إعدادات البلوتوث للاقتران')),
        if (msg.isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(msg, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      ]);
    }
    return Scaffold(
      appBar: AppBar(title: const Text('لعب بالبلوتوث')),
      body: Padding(padding: const EdgeInsets.all(16), child: body),
    );
  }
}

// ---------- صفحة اللعب ----------
class GamePage extends StatefulWidget {
  final Mode mode;
  final int diff;
  final bool host;
  final String opp;
  const GamePage({super.key, required this.mode, this.diff = 1, this.host = true, this.opp = 'الخصم'});
  @override
  State<GamePage> createState() => _GameState();
}

class _GameState extends State<GamePage> {
  List<String> b = List.filled(9, '');
  String turn = 'X';
  List<int>? line;
  bool over = false, connected = true, iWant = false, oppWants = false;
  List<int> hist = [];
  int round = 0, sMe = 0, sOpp = 0, sDraw = 0;
  String emoji = '';
  Timer? emojiT;
  int? hukm;
  String hukmWho = '';

  Mode get mode => widget.mode;
  bool get firstX => mode != Mode.bt || widget.host;
  String get me => ((round % 2 == 0) == firstX) ? 'X' : 'O';
  String get oppMark => me == 'X' ? 'O' : 'X';

  @override
  void initState() {
    super.initState();
    loadScores();
    if (mode == Mode.bt) {
      Bt.init();
      Bt.onEvent = onBt;
    }
    if (mode == Mode.ai && me == 'O') aiLater();
  }

  @override
  void dispose() {
    emojiT?.cancel();
    if (mode == Mode.bt) {
      Bt.close();
      Bt.onEvent = null;
    }
    super.dispose();
  }

  String get key => mode == Mode.ai ? 'ai${widget.diff}' : mode.name;

  Future<void> loadScores() async {
    if (mode == Mode.bt) return;
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      sMe = p.getInt('$key:me') ?? 0;
      sOpp = p.getInt('$key:opp') ?? 0;
      sDraw = p.getInt('$key:draw') ?? 0;
    });
  }

  Future<void> saveScores() async {
    if (mode == Mode.bt) return;
    final p = await SharedPreferences.getInstance();
    await p.setInt('$key:me', sMe);
    await p.setInt('$key:opp', sOpp);
    await p.setInt('$key:draw', sDraw);
  }

  void place(int i, String m) {
    b[i] = m;
    hist.add(i);
    final w = winLine(b);
    setState(() {
      if (w != null) {
        over = true;
        line = w;
        if (m == me) {
          sMe++;
        } else {
          sOpp++;
        }
      } else if (!b.contains('')) {
        over = true;
        sDraw++;
      } else {
        turn = m == 'X' ? 'O' : 'X';
      }
    });
    if (over) {
      saveScores();
      HapticFeedback.heavyImpact();
      if (w != null) onLoss(m != me); // الفائز ليس أنا = أنا الخاسر
    } else {
      HapticFeedback.selectionClick();
    }
  }

  void onLoss(bool loserIsMe) {
    if (mode == Mode.local) {
      showHukm(Random().nextInt(hukms.length), loserIsMe ? 'لاعب 1' : 'لاعب 2');
    } else if (loserIsMe) {
      final i = Random().nextInt(hukms.length);
      if (mode == Mode.bt) Bt.send(jsonEncode({'t': 'hukm', 'i': i}));
      showHukm(i, 'أنت');
    }
  }

  void showHukm(int i, String who) {
    setState(() {
      hukm = i;
      hukmWho = who;
    });
    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted || hukm != i) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          icon: const Icon(Icons.gavel),
          title: Text(who == 'أنت' ? 'خسرت! حكمك:' : 'الخاسر ($who) عليه:'),
          content: Text(hukms[i], textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, height: 1.6)),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('تمام'))],
        ),
      );
    });
  }

  void aiLater() {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (!mounted || over || turn == me || mode != Mode.ai) return;
      place(aiMove(b, oppMark, me, widget.diff), oppMark);
    });
  }

  void tap(int i) {
    if (over || b[i] != '' || !connected) return;
    if (mode == Mode.local) {
      place(i, turn);
      return;
    }
    if (turn != me) return;
    place(i, me);
    if (mode == Mode.bt) {
      Bt.send(jsonEncode({'t': 'move', 'i': i}));
    } else if (!over) {
      aiLater();
    }
  }

  void onBt(String type, String data) {
    if (!mounted) return;
    if (type == 'disconnected' || type == 'error') {
      setState(() => connected = false);
      return;
    }
    if (type != 'msg') return;
    Map<String, dynamic> m;
    try {
      m = jsonDecode(data) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final t = m['t'];
    if (t == 'move') {
      final i = m['i'] as int;
      if (!over && i >= 0 && i < 9 && b[i] == '' && turn == oppMark) place(i, oppMark);
    } else if (t == 'rematch') {
      oppWants = true;
      if (iWant) {
        newRound();
      } else {
        setState(() {});
      }
    } else if (t == 'hukm') {
      final i = m['i'] as int;
      if (i >= 0 && i < hukms.length) showHukm(i, widget.opp);
    } else if (t == 'emoji') {
      showEmoji(m['e'] as String);
    }
  }

  void showEmoji(String e) {
    emojiT?.cancel();
    setState(() => emoji = e);
    emojiT = Timer(const Duration(seconds: 2), () {
      if (mounted) setState(() => emoji = '');
    });
  }

  void newRound() {
    setState(() {
      round++;
      b = List.filled(9, '');
      turn = 'X';
      line = null;
      over = false;
      hist = [];
      iWant = false;
      oppWants = false;
      hukm = null;
    });
    if (mode == Mode.ai && me == 'O') aiLater();
  }

  void rematch() {
    if (mode == Mode.bt) {
      iWant = true;
      Bt.send(jsonEncode({'t': 'rematch'}));
      if (oppWants) {
        newRound();
      } else {
        setState(() {});
      }
    } else {
      newRound();
    }
  }

  void replay() {
    b = List.filled(9, '');
    for (var k = 0; k < hist.length; k++) {
      b[hist[k]] = k % 2 == 0 ? 'X' : 'O';
    }
    turn = hist.length % 2 == 0 ? 'X' : 'O';
    line = null;
  }

  void undo() {
    if (over || hist.isEmpty || mode == Mode.bt) return;
    setState(() {
      do {
        hist.removeLast();
        replay();
      } while (mode == Mode.ai && hist.isNotEmpty && turn != me);
    });
    if (mode == Mode.ai && turn != me) aiLater();
  }

  String status(List<String> names) {
    if (!connected) return 'انقطع الاتصال';
    final ln = line;
    if (over) {
      if (ln == null) return 'تعادل!';
      final w = b[ln[0]];
      if (mode == Mode.local) return w == me ? 'فاز اللاعب 1' : 'فاز اللاعب 2';
      return w == me ? 'فزت! 🎉' : 'فاز ${names[1]}';
    }
    if (mode == Mode.local) return 'دور ${turn == me ? names[0] : names[1]}';
    return turn == me ? 'دورك' : 'دور ${names[1]}';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final hk = hukm;
    final names = mode == Mode.local
        ? ['لاعب 1', 'لاعب 2']
        : mode == Mode.ai
            ? ['أنت', 'الكمبيوتر']
            : ['أنت', widget.opp];
    Color cOf(String m) => m == 'X' ? cfg.xc : cfg.oc;

    Widget chip(String name, String score, Color c, bool active, [String extra = '']) => Expanded(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
            decoration: BoxDecoration(
              color: active ? c.withAlpha(46) : cs.surfaceContainerHighest.withAlpha(130),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: active ? c : Colors.transparent, width: 2),
            ),
            child: Column(children: [
              Text('$name$extra', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
              Text(score, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: c)),
            ]),
          ),
        );

    final canRematch = mode != Mode.bt || (over && connected);
    return Scaffold(
      appBar: AppBar(
        title: Text(mode == Mode.ai ? 'ضد الكمبيوتر' : mode == Mode.local ? 'لاعبان' : 'بلوتوث'),
        actions: [
          if (mode != Mode.bt)
            IconButton(icon: const Icon(Icons.undo), tooltip: 'تراجع', onPressed: undo),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(children: [
                Row(children: [
                  chip(names[0], '$sMe', cOf(me), !over && turn == me, ' (${me})'),
                  const SizedBox(width: 8),
                  chip('تعادل', '$sDraw', cs.outline, false),
                  const SizedBox(width: 8),
                  chip(names[1], '$sOpp', cOf(oppMark), !over && turn == oppMark, ' (${oppMark})'),
                ]),
                const SizedBox(height: 8),
                SizedBox(
                  height: 36,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: Text(emoji.isNotEmpty ? '${names[1]}: $emoji' : '', key: ValueKey(emoji), style: const TextStyle(fontSize: 24)),
                  ),
                ),
                Text(status(names), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                if (hk != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: cs.tertiaryContainer, borderRadius: BorderRadius.circular(14)),
                      child: Text(
                        '${hukmWho == 'أنت' ? 'حكمك' : 'حكم $hukmWho'}: ${hukms[hk]}',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: cs.onTertiaryContainer),
                      ),
                    ),
                  ),
                const SizedBox(height: 18),
                Board(cells: b, line: line, onTap: tap),
                const SizedBox(height: 22),
                if (canRematch)
                  FilledButton.icon(
                    onPressed: (mode == Mode.bt && iWant) ? null : rematch,
                    icon: const Icon(Icons.refresh),
                    label: Text(mode == Mode.bt
                        ? (iWant ? 'بانتظار الخصم...' : oppWants ? 'الخصم يريد جولة جديدة، وافق' : 'جولة جديدة')
                        : 'جولة جديدة'),
                  ),
                if (mode == Mode.bt && connected) ...[
                  const SizedBox(height: 14),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    for (final e in ['👍', '😂', '😮', '🔥'])
                      IconButton(
                        onPressed: () => Bt.send(jsonEncode({'t': 'emoji', 'e': e})),
                        icon: Text(e, style: const TextStyle(fontSize: 28)),
                      ),
                  ]),
                ],
                if (mode == Mode.bt && !connected)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('رجوع')),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
